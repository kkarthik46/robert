package com.caltech.pojo;



import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.caltech.dbconfig.DbUtil;

/*StandardServiceRegistry
Metadata
SessionFactory
Session
Transaction
Close the connection
*/
public class EmployeeMain {
public static void main(String[] args) {
	DbUtil dbconfig=new DbUtil();
	Session session=dbconfig.dbConn();
	if(session!=null) {
		System.out.println("db configurations are done");
	}
	else {
		System.out.println("connection with db failed");
	}
	//this object is used to commit / save our db operations
	Transaction tran=session.beginTransaction();
	Scanner sc=new Scanner(System.in);
//	for(int i=1;i<=20;i++) {
//	Employee e=new Employee();
//	e.setEmpname("name"+i);
//	e.setEmpemail("name"+i+"@g.c");
//	session.save(e);
//}
	
	//HQL
	//get all the employee records
/*Query-interface
Session object
createQuery()
single record: q.unquieResult();
list of records: q.list();
*/
	//get all the records of an employee
//	Query q=session.createQuery("from Employee");
//	List<Employee> list=q.list();
//	System.out.println(list);
	
	//get the record of the empno=2
//	Query q1=session.createQuery("from Employee where empno=2");
//	Employee e=(Employee) q1.uniqueResult();
//	System.out.println(e);
//	
	//get the record of the empno>2
//	Query q=session.createQuery("from Employee where empno>2");
//	List<Employee> list=q.list();
//	System.out.println(list);
	
    //get the record of only few columns empname,empemail for empno=2
//	Query q=session.createQuery("select empname,empemail from Employee where empno=2");
//	Object[] e=(Object[]) q.uniqueResult();
//	System.out.println(e[0]+" "+e[1]);
	
	//>2
	Query q=session.createQuery("select empname,empemail from Employee where empno>2");
	List<Object[]> e=q.list();
		for(Object emp[]:e) {
			System.out.println(emp[0]+"   "+emp[1]);
		}	
tran.commit();
}
}
