package com.caltech.dao;

import org.hibernate.Session;

import com.caltech.pojo.Employee;

public class EmpDAO {
	
	public String insert(Session session,Employee e) {
		//return an object of Integer
		//return the pK value
		int row=(int) session.save(e);
		if(row>0) {
			return "insertion done";
		}
		else {
			return "insertion failed";
		}
	}
	
	public String update(Session session,Employee e) {
		session.saveOrUpdate(e);
		return "updated";
	}
	
	public String delete(Session session,Employee e) {
		session.delete(e);
		return "deleted the record with the id as "+e.getEmpno();
	}
	//depending on id bring the details
	public Employee retrieve(Session session,int id) {
		return session.get(Employee.class,id);
	}

}
